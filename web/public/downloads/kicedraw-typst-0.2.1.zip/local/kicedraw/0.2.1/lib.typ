#let engine = plugin.transition(plugin("kicedraw.wasm").init)
#let render(source, sizes: none, dark: false, viewport-width: none, output-width-mm: none) = json(engine.render(bytes(json.encode((source: source, sizes: sizes, dark: dark, viewportWidth: viewport-width, outputWidthMm: output-width-mm)))))

// Only math tokens, not arbitrary Typst code, may come from a DSL file.
#let formula(source) = {
  let s = source.replace(regex("\\\\mathrm\\{([a-zA-Z0-9]+)\\}"), m => "upright(" + m.captures.first() + ")")
  s = s.replace(regex("\\\\rm\\s+([a-zA-Z0-9]+)"), m => "upright(" + m.captures.first() + ")")
  assert(s.match(regex("^[a-zA-Z0-9_ +*/=.,()^<>:−×÷≤≥√π-]+$")) != none and not s.contains("//") and not s.contains("/*"), message: "Unsupported kicedraw formula: " + source)
  for word in s.matches(regex("[a-zA-Z]{2,}")) {
    assert(word.text in ("upright", "frac", "sqrt", "root", "sin", "cos", "tan", "log", "lim", "sum", "pi", "theta", "alpha", "beta", "gamma", "delta", "infinity"), message: "Unsupported kicedraw math name: " + word.text)
  }
  eval(s, mode: "math")
}

#let kicedraw(source, width: auto, height: auto, alt: none, math-labels: (:), dark: false, viewport-width: none, output-width-mm: none) = context {
  let dsl = if type(source) == content and source.func() == raw { source.text } else { source }
  assert(type(dsl) == str, message: "kicedraw: expected DSL text or a raw block")
  let draw = render.with(dark: dark, viewport-width: viewport-width, output-width-mm: output-width-mm)
  let scene = draw(dsl)
  // Compose the geometry and native equations at their design size first.
  // A Typst width/height changes only the final uniform transform, not layout.
  let mm = scene.svg.match(regex("<svg[^>]*? width=\"([0-9.]+)mm\""))
  let base = if mm == none { scene.w * 0.75pt } else { float(mm.captures.first()) * 1mm }
  let unit = base / scene.w
  let natural-height = scene.h * unit
  let resized(body) = if width == auto and height == auto { body } else { layout(region => {
    let w = if width != auto { measure(box(width: width), width: region.width).width / base }
    let h = if height != auto { measure(box(height: height), height: region.height).height / natural-height }
    let factor = if w == none { h } else if h == none { w } else { calc.min(w, h) }
    scale(x: factor * 100%, y: factor * 100%, origin: top + left, reflow: true, body)
  }) }
  let graphic(s) = image(bytes(s.svg), format: "svg", width: base, alt: alt)
  if scene.formulas.len() == 0 { return resized(graphic(scene)) }
  let bodies = scene.formulas.map(f => {
    let body = if f.source in math-labels { math-labels.at(f.source) } else { formula(f.source) }
    box(text(size: f.size * unit, fill: rgb(f.color), body))
  })
  let sizes = bodies.map(b => { let m = measure(b); (m.width / unit, m.height / unit) })
  scene = draw(dsl, sizes: sizes)
  resized(box(width: base, height: natural-height, clip: true, {
    place(top + left, graphic(scene))
    for label in scene.labels {
      place(top + left, dx: label.x * unit, dy: label.y * unit, bodies.at(label.id))
    }
  }))
}
